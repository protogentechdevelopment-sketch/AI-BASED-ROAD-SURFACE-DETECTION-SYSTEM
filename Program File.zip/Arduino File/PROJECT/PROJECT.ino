/* Edge Impulse Arduino examples
 * Copyright (c) 2022 EdgeImpulse Inc.
 */

#include <plant_disease_inferencing.h>
#include "edge-impulse-sdk/dsp/image/image.hpp"
#include "esp_camera.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include <base64.h>
#include <WiFiClientSecure.h>  
#define CAMERA_MODEL_AI_THINKER

#if defined(CAMERA_MODEL_AI_THINKER)
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22
#else
#error "Camera model not selected"
#endif

// ─── WiFi & imgBB config ─────────────────────────────────────────────────────
#define WIFI_SSID           "project"
#define WIFI_PASSWORD       "12345678"
#define IMGBB_API_KEY       "42122901c34848cafc28db18bc1fdb8a"
#define IMGBB_UPLOAD_URL    "https://api.imgbb.com/1/upload"
// ────────────────────────────────────────────────────────────────────────────

// ─── UART2 config ────────────────────────────────────────────────────────────
#define UART_BAUD             9600
#define UART_TX_PIN           14
#define UART_RX_PIN           15
#define CONFIDENCE_THRESHOLD  0.7f
// ────────────────────────────────────────────────────────────────────────────

#define EI_CAMERA_RAW_FRAME_BUFFER_COLS     320
#define EI_CAMERA_RAW_FRAME_BUFFER_ROWS     240
#define EI_CAMERA_FRAME_BYTE_SIZE           3

static bool debug_nn = false;
static bool is_initialised = false;
uint8_t *snapshot_buf;

// ─── JPEG buffer globals ──────────────────────────────────────────────────────
uint8_t *jpeg_buf = nullptr;
size_t   jpeg_len = 0;
// ────────────────────────────────────────────────────────────────────────────

static camera_config_t camera_config = {
    .pin_pwdn  = PWDN_GPIO_NUM,  .pin_reset = RESET_GPIO_NUM,
    .pin_xclk  = XCLK_GPIO_NUM,
    .pin_sscb_sda = SIOD_GPIO_NUM, .pin_sscb_scl = SIOC_GPIO_NUM,
    .pin_d7 = Y9_GPIO_NUM, .pin_d6 = Y8_GPIO_NUM, .pin_d5 = Y7_GPIO_NUM,
    .pin_d4 = Y6_GPIO_NUM, .pin_d3 = Y5_GPIO_NUM, .pin_d2 = Y4_GPIO_NUM,
    .pin_d1 = Y3_GPIO_NUM, .pin_d0 = Y2_GPIO_NUM,
    .pin_vsync = VSYNC_GPIO_NUM, .pin_href = HREF_GPIO_NUM,
    .pin_pclk  = PCLK_GPIO_NUM,
    .xclk_freq_hz = 20000000,
    .ledc_timer   = LEDC_TIMER_0,
    .ledc_channel = LEDC_CHANNEL_0,
    .pixel_format = PIXFORMAT_JPEG,
    .frame_size   = FRAMESIZE_QVGA,
    .jpeg_quality = 12,
    .fb_count     = 1,
    .fb_location  = CAMERA_FB_IN_PSRAM,
    .grab_mode    = CAMERA_GRAB_WHEN_EMPTY,
};

bool ei_camera_init(void);
void ei_camera_deinit(void);
bool ei_camera_capture(uint32_t img_width, uint32_t img_height, uint8_t *out_buf);

// ─── WiFi Connect ────────────────────────────────────────────────────────────
void connectWiFi() {
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    ei_printf("Connecting to WiFi");
    int retry = 0;
    while (WiFi.status() != WL_CONNECTED && retry < 20) {
        delay(500);
        ei_printf(".");
        retry++;
    }
    if (WiFi.status() == WL_CONNECTED) {
        ei_printf("\nWiFi connected! IP: %s\n", WiFi.localIP().toString().c_str());
    } else {
        ei_printf("\nWiFi connection failed!\n");
    }
}
// ────────────────────────────────────────────────────────────────────────────

// ─── Capture JPEG before inference ───────────────────────────────────────────
void captureJPEG() {
    if (jpeg_buf) {
        free(jpeg_buf);
        jpeg_buf = nullptr;
        jpeg_len = 0;
    }
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
        ei_printf("[JPEG] Capture failed\n");
        return;
    }
    jpeg_buf = (uint8_t*)malloc(fb->len);
    if (jpeg_buf) {
        memcpy(jpeg_buf, fb->buf, fb->len);
        jpeg_len = fb->len;
        ei_printf("[JPEG] Captured %d bytes\n", jpeg_len);
    }
    esp_camera_fb_return(fb);
}
// ────────────────────────────────────────────────────────────────────────────

// ─── imgBB Upload ────────────────────────────────────────────────────────────
void uploadToImgBB(const char* label) {
    if (WiFi.status() != WL_CONNECTED) {
        ei_printf("[imgBB] WiFi not connected\n");
        return;
    }
    if (!jpeg_buf || jpeg_len == 0) {
        ei_printf("[imgBB] No JPEG buffer\n");
        return;
    }

    WiFiClientSecure client;
    client.setInsecure();
    client.setTimeout(30);

    HTTPClient http;
    http.setTimeout(30000);

    String url = "https://api.imgbb.com/1/upload?key=42122901c34848cafc28db18bc1fdb8a";

    // URL encode base64
    String base64Image = base64::encode(jpeg_buf, jpeg_len);
    base64Image.replace("+", "%2B");
    base64Image.replace("/", "%2F");
    base64Image.replace("=", "%3D");

    String payload = "image=" + base64Image + "&name=" + String(label);

    if (!http.begin(client, url)) {
        ei_printf("[imgBB] http.begin failed\n");
        return;
    }

    http.addHeader("Content-Type", "application/x-www-form-urlencoded");
    int code = http.POST(payload);
    ei_printf("[imgBB] HTTP code: %d\n", code);

    if (code == 200) {
        String response = http.getString();
        int urlStart = response.indexOf("\"display_url\":\"") + 15;
        int urlEnd   = response.indexOf("\"", urlStart);
        String imgUrl = response.substring(urlStart, urlEnd);
        imgUrl.replace("\\/", "/");
        ei_printf("[imgBB] Upload success!\n");
        ei_printf("[imgBB] URL: %s\n", imgUrl.c_str());
    } else {
        ei_printf("[imgBB] Upload failed: %s\n", http.errorToString(code).c_str());
    }

    http.end();
}
// ────────────────────────────────────────────────────────────────────────────

// ─── UART Send ───────────────────────────────────────────────────────────────
void sendDiseaseUART(const char* label, float confidence) {
    String msg = String(label) + " " + String(confidence * 100.0f, 1) + "%";
    Serial2.println(msg);
    ei_printf("[UART SENT] %s\n", msg.c_str());
}
// ────────────────────────────────────────────────────────────────────────────

void setup()
{
    Serial.begin(115200);
    while (!Serial);

    Serial2.begin(UART_BAUD, SERIAL_8N1, UART_RX_PIN, UART_TX_PIN);
    ei_printf("UART2 initialized (TX=GPIO%d, Baud=%d)\n", UART_TX_PIN, UART_BAUD);

    connectWiFi();

    Serial.println("Edge Impulse Inferencing Demo");

    if (ei_camera_init() == false)
        ei_printf("Failed to initialize Camera!\r\n");
    else
        ei_printf("Camera initialized\r\n");

    ei_printf("\nStarting continuous inference in 2 seconds...\n");
    ei_sleep(2000);
}

void loop()
{
    if (ei_sleep(5) != EI_IMPULSE_OK) return;

    snapshot_buf = (uint8_t*)malloc(
        EI_CAMERA_RAW_FRAME_BUFFER_COLS *
        EI_CAMERA_RAW_FRAME_BUFFER_ROWS *
        EI_CAMERA_FRAME_BYTE_SIZE);

    if (snapshot_buf == nullptr) {
        ei_printf("ERR: Failed to allocate snapshot buffer!\n");
        return;
    }

    ei::signal_t signal;
    signal.total_length = EI_CLASSIFIER_INPUT_WIDTH * EI_CLASSIFIER_INPUT_HEIGHT;
    signal.get_data = &ei_camera_get_data;

    if (ei_camera_capture((size_t)EI_CLASSIFIER_INPUT_WIDTH,
                          (size_t)EI_CLASSIFIER_INPUT_HEIGHT,
                          snapshot_buf) == false) {
        ei_printf("Failed to capture image\r\n");
        free(snapshot_buf);
        return;
    }

    ei_impulse_result_t result = { 0 };
    EI_IMPULSE_ERROR err = run_classifier(&signal, &result, debug_nn);
    if (err != EI_IMPULSE_OK) {
        ei_printf("ERR: Failed to run classifier (%d)\n", err);
        free(snapshot_buf);
        return;
    }

    free(snapshot_buf);

    ei_printf("Predictions (DSP: %d ms., Classification: %d ms., Anomaly: %d ms.):\n",
              result.timing.dsp, result.timing.classification, result.timing.anomaly);

#if EI_CLASSIFIER_OBJECT_DETECTION == 1
    // Find highest confidence bbox first
    float best_val = 0.0f;
    int best_bb = -1;
    for (uint32_t i = 0; i < result.bounding_boxes_count; i++) {
        if (result.bounding_boxes[i].value > best_val) {
            best_val = result.bounding_boxes[i].value;
            best_bb  = i;
        }
    }

    for (uint32_t i = 0; i < result.bounding_boxes_count; i++) {
        ei_impulse_result_bounding_box_t bb = result.bounding_boxes[i];
        if (bb.value == 0) continue;
        ei_printf("  %s (%f) [ x: %u, y: %u, width: %u, height: %u ]\r\n",
                  bb.label, bb.value, bb.x, bb.y, bb.width, bb.height);
    }

    if (best_bb >= 0 && best_val >= CONFIDENCE_THRESHOLD) {
        captureJPEG();   // inference பிறகு fresh JPEG
        sendDiseaseUART(result.bounding_boxes[best_bb].label, best_val);
        uploadToImgBB(result.bounding_boxes[best_bb].label);
    } else {
        ei_printf("[SKIPPED] confidence too low\n");
    }

#else
    float best_confidence = 0.0f;
    int   best_index      = -1;

    for (uint16_t i = 0; i < EI_CLASSIFIER_LABEL_COUNT; i++) {
        float conf = result.classification[i].value;
        ei_printf("  %s: %.5f\r\n", ei_classifier_inferencing_categories[i], conf);
        if (conf > best_confidence) {
            best_confidence = conf;
            best_index      = i;
        }
    }

    if (best_index >= 0 && best_confidence >= CONFIDENCE_THRESHOLD) {
        captureJPEG();   // inference பிறகு fresh JPEG
        sendDiseaseUART(ei_classifier_inferencing_categories[best_index], best_confidence);
        uploadToImgBB(ei_classifier_inferencing_categories[best_index]);
    } else {
        ei_printf("[SKIPPED] Top prediction confidence too low (%.2f%%)\n",
                  best_confidence * 100.0f);
    }
#endif

#if EI_CLASSIFIER_HAS_ANOMALY
    ei_printf("Anomaly prediction: %.3f\r\n", result.anomaly);
#endif
}

// ─── Camera functions ────────────────────────────────────────────────────────
bool ei_camera_init(void) {
    if (is_initialised) return true;
    esp_err_t err = esp_camera_init(&camera_config);
    if (err != ESP_OK) {
        Serial.printf("Camera init failed with error 0x%x\n", err);
        return false;
    }
    sensor_t *s = esp_camera_sensor_get();
    if (s->id.PID == OV3660_PID) {
        s->set_vflip(s, 1);
        s->set_brightness(s, 1);
        s->set_saturation(s, 0);
    }
    is_initialised = true;
    return true;
}

void ei_camera_deinit(void) {
    esp_err_t err = esp_camera_deinit();
    if (err != ESP_OK) { ei_printf("Camera deinit failed\n"); return; }
    is_initialised = false;
}

bool ei_camera_capture(uint32_t img_width, uint32_t img_height, uint8_t *out_buf) {
    if (!is_initialised) { ei_printf("ERR: Camera is not initialized\r\n"); return false; }
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) { ei_printf("Camera capture failed\n"); return false; }
    bool converted = fmt2rgb888(fb->buf, fb->len, PIXFORMAT_JPEG, snapshot_buf);
    esp_camera_fb_return(fb);
    if (!converted) { ei_printf("Conversion failed\n"); return false; }
    if ((img_width != EI_CAMERA_RAW_FRAME_BUFFER_COLS)
        || (img_height != EI_CAMERA_RAW_FRAME_BUFFER_ROWS)) {
        ei::image::processing::crop_and_interpolate_rgb888(
            out_buf, EI_CAMERA_RAW_FRAME_BUFFER_COLS,
            EI_CAMERA_RAW_FRAME_BUFFER_ROWS,
            out_buf, img_width, img_height);
    }
    return true;
}

static int ei_camera_get_data(size_t offset, size_t length, float *out_ptr) {
    size_t pixel_ix = offset * 3;
    size_t pixels_left = length;
    size_t out_ptr_ix = 0;
    while (pixels_left != 0) {
        out_ptr[out_ptr_ix] = (snapshot_buf[pixel_ix + 2] << 16)
                            + (snapshot_buf[pixel_ix + 1] << 8)
                            +  snapshot_buf[pixel_ix];
        out_ptr_ix++; pixel_ix += 3; pixels_left--;
    }
    return 0;
}

#if !defined(EI_CLASSIFIER_SENSOR) || EI_CLASSIFIER_SENSOR != EI_CLASSIFIER_SENSOR_CAMERA
#error "Invalid model for current sensor"
#endif